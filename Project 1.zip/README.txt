CloudFront domain name URL:
https://d150k7wv9xba0i.cloudfront.net

 Website-endpoint URL:
http://my-174598002066-bucket.s3-website-us-east-1.amazonaws.com/

